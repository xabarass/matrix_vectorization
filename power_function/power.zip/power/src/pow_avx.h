#include <immintrin.h>
#include <math.h> // you will probably not ned this header

void pow_avx_init () {
    // perform initialization here
}


double pow_avx (double x, uint32_t n_int) {
    // write your implementation here

    // use pow, so we don get error in validation.
    return pow(x, n_int);
}