#ifndef POW_H
#define POW_H

#include <stdint.h>

void   pow_avx_init ();
double pow_avx      (double x, uint32_t n);
double pow_scalar   (double x, uint32_t n);

#endif /* POW_H */