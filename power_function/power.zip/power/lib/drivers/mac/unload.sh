#!/usr/bin/env bash

kextunload /System/Library/Extensions/PcmMsrDriver.kext
rm -rf /System/Library/Extensions/PcmMsrDriver.kext